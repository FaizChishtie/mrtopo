"""
    MrTopo Logger - logs information
"""

def log(item, level=""):
    print(level, item)