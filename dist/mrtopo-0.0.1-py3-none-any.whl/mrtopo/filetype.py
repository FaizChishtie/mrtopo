from enum import Enum


class FileType(Enum):
    NOFILE = 0
    PYTHON = 1
    CONFIG = 2
