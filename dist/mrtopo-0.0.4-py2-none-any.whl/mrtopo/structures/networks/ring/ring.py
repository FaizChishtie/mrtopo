"""
    MrTopo Network - data structure repr Ring Topo
"""

from mininet.topo import Topo

class RingTopo(Topo):
    def build(self):
        pass # TODO