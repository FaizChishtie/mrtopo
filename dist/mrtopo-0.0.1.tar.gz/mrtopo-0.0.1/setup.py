import setuptools

with open("README.md", "r") as fh:
    long_description = fh.read()

setuptools.setup(
    name='mrtopo',
    version='0.0.1',
    packages=setuptools.find_packages(),
    url='https://github.com/FaizChishtie/mrtopo',
    license='MIT',
    author='faizchishtie',
    author_email='faizchishtie@gmail.com',
    description='Mutate Mininet topology files with MrTopo',
    entry_points={'console_scripts': ['mrtopo = mrtopo.__main__:main']},
    long_description=long_description
)
